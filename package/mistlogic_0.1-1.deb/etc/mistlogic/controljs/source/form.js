class Form {
    handleForm(e){
	e.preventDefault();
	console.log(e);
    }
}

export default Form;
