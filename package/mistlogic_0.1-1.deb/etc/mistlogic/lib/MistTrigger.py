import RPi.GPIO as GPIO

class deviceTrigger(object):

    def __init__(self, state):
        self.state = state
        self.__change()

    def __change(self):
        ledPin = 23
        print self.state['manual']

        GPIO.setmode(GPIO.BCM)
        GPIO.setup(ledPin, GPIO.OUT)

        if self.state['manual']:
            GPIO.output(ledPin, GPIO.LOW)
        else:
            GPIO.output(ledPin, GPIO.HIGH)
